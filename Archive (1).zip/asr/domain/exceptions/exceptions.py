class SessionASRInconnue(Exception):
    pass
